// 1. Fix Modal overlay

// Open Modal.tsx from resources/scripts/components/elements directory
// Search for
${tw`fixed z-50 overflow-auto flex w-full inset-0`};

// Replace with
${tw`fixed overflow-auto flex w-full inset-0`};

// After  background: rgba(0, 0, 0, 0.7); add
z-index: 9999;

// Example Screenshot 1




// 2. Fix Console Spinner Issue

// Open Console.tsx from resources/scripts/components/server/console directory
// Search for
<div className='terminal' ref={ref}></div>

// Replace with
<div className='terminal min-h-[100px]' ref={ref}></div>


// Example Screenshot 2



// After that you have to build the assets using the command
yarn run build:production



// Enjoy!