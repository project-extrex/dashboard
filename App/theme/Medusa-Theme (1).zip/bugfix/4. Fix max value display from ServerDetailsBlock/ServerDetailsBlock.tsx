// Search for
<span>(Max: {bytesToString(limits.disk)})</span>;

// Replace with
<span>(Max: {mbToGb(limits.disk)})</span>;
