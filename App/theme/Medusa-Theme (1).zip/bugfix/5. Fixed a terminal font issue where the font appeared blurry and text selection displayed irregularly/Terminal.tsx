// Search for
& .terminal .xterm-text-layer {
    ${tw`p-2`};
}

// Replace with
.xterm-screen {
    ${tw`!my-2`};
}

& .terminal .xterm-text-layer {
    ${tw`p-0 mx-2`};
}

// DONE! Check the screenshot to see if you modified it right