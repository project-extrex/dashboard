// Go to the resources/scripts/medusa/components
// and open the StatusIndicatorBox.tsx file

// >> STEP 01:
// Search for:
maxValue={Math.ceil(diskLimit === 0 ? Infinity : diskLimit)}


// replace with
maxValue={status === 'offline' ? Math.ceil(diskLimit === 0 ? 0 : diskLimit) : Math.ceil(diskLimit === 0 ? Infinity : diskLimit)}


// >> STEP 02:
// Search for:
(Max: {!isSuspended ? bytesToString(mbToBytes(diskUsage)) : '-'})

// replace with
(Max: {isSuspended ? '-' : diskLimit === 0 ? '∞' : mbToGb(diskLimit)})