// Search
{subusers.length > 1 && subusers.map((subuser) => <UserRow key={subuser.uuid} subuser={subuser} />)}

// replace with
{subusers.length >= 1 && subusers.map((subuser) => <UserRow key={subuser.uuid} subuser={subuser} />)}