public static function generic_downloader_svgrepo_com($size) {
    return <<<SVG
<?xml version="1.0" encoding="utf-8"?>
<!-- Uploaded to: SVG Repo, www.svgrepo.com, Generator: SVG Repo Mixer Tools -->
<svg {$size} {$size} viewBox="0 0 192 192" xmlns="http://www.w3.org/2000/svg" fill="none">

<g stroke="#000000" stroke-width="12" clip-path="url(#a)">

<path stroke-linecap="round" stroke-linejoin="round" d="m54 104 42 42 42-42m-42 28V46"/>

<circle cx="96" cy="96" r="74"/>

</g>

<defs>

<clipPath id="a">

<path fill="#ffffff" d="M0 0h192v192H0z"/>

</clipPath>

</defs>

</svg>
SVG;
}